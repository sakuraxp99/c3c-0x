var fetch = global.nodemodule["node-fetch"];
var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];
var merge = global.nodemodule["merge-images"];
var waiton =global.nodemodule["wait-on"];
var Jimp = global.nodemodule["jimp"];
var { Canvas, Image } = global.nodemodule["canvas"];
var time = new Date();
function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}
var rootpath = path.resolve(__dirname, "..", "Punch");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "images"));
ensureExists(path.join(rootpath, "temp"));
var nameMapping = {
    "married_template": path.join(rootpath, "images", "married_template.jpg"),
    "punch": path.join(rootpath, "images", "punch.jpg")
}

for (var n in nameMapping) {
    if (!fs.existsSync(nameMapping[n])) {
        fs.writeFileSync(nameMapping[n], global.fileMap[n]);
    }
}
function sO(object) {
    return Object.keys(object).length;
}
var married = function (type, datas) {
    var sender = datas.msgdata.senderID;
    var mentions = datas.mentions;
    var UserAvatar = "UserAvatar_" + Date.now() + ".jpg";
    var UserAvatar1 = "UserAvatar1_" + Date.now() + ".jpg";
    var succ = "Success_" + Date.now() + ".jpg";
    
    if (sO(mentions) == 1) {
        Jimp.read("https://graph.facebook.com/" + sender + "/picture?height=720&width=720&access_token=341042286790564|b8c27b5d9d4282555aa7d4e110fd794f").then(img => {
            img.resize(180, 180);
            img.write(path.join(rootpath, "temp", UserAvatar));
        }).catch(err => {
            datas.log(err);
        });
        Jimp.read("https://graph.facebook.com/" + Object.keys(mentions)[0].slice(3) + "/picture?height=720&width=720&access_token=341042286790564|b8c27b5d9d4282555aa7d4e110fd794f").then(img => {
            img.resize(180, 180);
            img.write(path.join(rootpath, "temp", UserAvatar1));
        }).catch(err => {
            datas.log(err);
        });
        waiton({
            resources: [
                path.join(rootpath, "temp", UserAvatar),
                path.join(rootpath, "temp", UserAvatar1)
                        ],
            timeout: 5000
        }).then(function () {
            merge(
                [
                {
                    src: path.join(rootpath, "images", "married_template.jpg")
                },
                {
                    src: path.join(rootpath, "temp", UserAvatar),
                    x: 270,
                    y: 185
                },
                {
                    src: path.join(rootpath, "temp", UserAvatar1),
                    x: 570,
                    y: 280
                }
                ], {
                Canvas: Canvas,
                Image: Image
                   }
                ).then(function (res) {
                    
                fs.writeFile(
                    path.join(rootpath, "temp", succ), 
                    res.replace(/^data:image\/png;base64,/, ""), 
                    'base64', 
                    function (err) {
                        
                    if (err) datas.log(err);
                    
                        var img = fs.createReadStream(path.join(rootpath, "temp", succ));
                        
                        datas.return({
                            handler: "internal-raw",
                            data: {
                                body: "🎉 Chúc hai bạn Hạnh phúc <3 \nduoi suoi vang >:)",
                                attachment: ([img])
                            }
                        });
                        img.on("close", () => {
                        try {
                        fs.unlinkSync(path.join(rootpath, "temp", UserAvatar));
                        fs.unlinkSync(path.join(rootpath, "temp", UserAvatar1));
                        fs.unlinkSync(path.join(rootpath, "temp", succ));
                        } catch (err) {}
                        })
                });
            }).catch(err => {
                datas.log(err);
            });
        }).catch(err => {
                datas.log(err);
            });
    } else {
        datas.return({
            handler: 'internal',
            data: global.config.commandPrefix+'married <@mentions> [Married]'
        })
    }
 }
var punch = function (type, data) {
    var sender = data.msgdata.senderID;
    var mentions = data.mentions;
	var UserAvatar = "UserAvatar_" + Date.now() + ".jpg";
	var UserAvatar1 = "UserAvatar1_" + Date.now() + ".jpg";
	var succ = "Success_" + Date.now() + ".jpg";
	
    if (sO(mentions) == 1) {
        Jimp.read("https://graph.facebook.com/" + sender + "/picture?height=720&width=720&access_token=341042286790564|b8c27b5d9d4282555aa7d4e110fd794f").then(img => {
            img.resize(180, 180);
            img.write(path.join(rootpath, "temp", UserAvatar));
        }).catch(err => {
            data.log(err);
        });
        Jimp.read("https://graph.facebook.com/" + Object.keys(mentions)[0].slice(3) + "/picture?height=720&width=720&access_token=341042286790564|b8c27b5d9d4282555aa7d4e110fd794f").then(img => {
            img.resize(180, 180);
            img.write(path.join(rootpath, "temp", UserAvatar1));
        }).catch(err => {
            data.log(err);
        });
        waiton({
            resources: [
				path.join(rootpath, "temp", UserAvatar),
				path.join(rootpath, "temp", UserAvatar1)
						],
            timeout: 5000
        }).then(function () {
            merge(
				[
				{
					src: path.join(rootpath, "images", "punch.jpg")
				},
                {
                    src: path.join(rootpath, "temp", UserAvatar),
                    x: 270,
                    y: 50
                },
                {
                    src: path.join(rootpath, "temp", UserAvatar1),
                    x: 500,
                    y: 480
                }
				], {
                Canvas: Canvas,
                Image: Image
				   }
				).then(function (res) {
					
                fs.writeFile(
					path.join(rootpath, "temp", succ), 
					res.replace(/^data:image\/png;base64,/, ""), 
					'base64', 
					function (err) {
						
                    if (err) data.log(err);
					
                        var img = fs.createReadStream(path.join(rootpath, "temp", succ));
						var name = global.data.cacheName["FB-" + Object.keys(mentions)[0].slice(3)]
                        data.return({
                            handler: "internal-raw",
                            data: {
                                body: `Thằng đầu cắt moi @${name}, bố đấm vỡ mồm 😡😡`,
                                mentions: [{
                                	tag: `@${name}`,
                                	id: Object.keys(mentions)[0].slice(3),
                                	fromIndex: 9
                                }],
                                attachment: ([img])
                            }
                        });
						img.on("close", () => {
						try {
                        fs.unlinkSync(path.join(rootpath, "temp", UserAvatar));
                        fs.unlinkSync(path.join(rootpath, "temp", UserAvatar1));
                        fs.unlinkSync(path.join(rootpath, "temp", succ));
						} catch (err) {}
						})
                });
            }).catch(err => {
                data.log(err);
            });
        }).catch(err => {
                data.log(err);
            });
    } else {
        return {
            handler: 'internal',
            data: global.config.commandPrefix+'punch <@mentions> [Đấm vỡ mồm]'
        }
    }
 }
module.exports = {
	punch: punch,
    married: married
}
