var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
var kannagen = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" ")); data.log(text)
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "kannagen <text> [text to kannagen]"
		}
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=kannagen&text=${text}&raw=1`);
			var buffer = await fetchdata.buffer();
				var kannagen = new streamBuffers.ReadableStreamBuffer({
					frequency: 10,
					chunkSize: 1024
				});
				kannagen.path = 'image.png';
				kannagen.put(buffer);
				kannagen.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([kannagen])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
var monika = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" ")); data.log(text)
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "monika <text> [text to monika]"
		}
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=ddlc&character=m&background=closet&body=2&face=b&text=${text}&raw=1`);
			var buffer = await fetchdata.buffer();
				var monika = new streamBuffers.ReadableStreamBuffer({
					frequency: 10,
					chunkSize: 1024
				});
				monika.path = 'image.png';
				monika.put(buffer);
				monika.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([monika])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
module.exports = {
	kannagen: kannagen,
	monika: monika
}