var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];
function onLoad(data) {

var onLoadText = "Loaded \"Goose\" - Source code by Kaysil and Trung";

data.log(onLoadText);

}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}
var rootpath = path.resolve(__dirname, "..", "Gose-data");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "temp"));

var goose = async function goose(type, data) {
	fetch("https://nekos.life/api/v2/img/goose")
			.then(res => res.json())
			.then(json => {
				var img = global.nodemodule['sync-request']("GET", json.url).body;
					fs.writeFileSync(path.join(rootpath, data.msgdata.messageID + ".jpg"), img);
				var stream = fs.createReadStream(path.join(rootpath, data.msgdata.messageID + ".jpg"));
				data.log(json);
				var obt = {
						body: ``,
						attachment: ([stream])
					};
				return data.facebookapi.sendMessage(obt, data.msgdata.threadID, data.msgdata.messageID);
			})
		}
module.exports = {
	goose: goose,
	onLoad
}
