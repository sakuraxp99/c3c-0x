var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];
function onLoad(data) {

var onLoadText = "Loaded \"Lizards\" - Source code by Kaysil and Trung";

data.log(onLoadText);

}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}
var rootpath = path.resolve(__dirname, "..", "Lizards-data");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "temp"));

var lizards = async function lizards(type, data) {
	fetch("https://nekos.life/api/v2/img/lizard")
			.then(res => res.json())
			.then(json => {
				var img = global.nodemodule['sync-request']("GET", json.url).body;
					fs.writeFileSync(path.join(rootpath, data.msgdata.messageID + ".png"), img);
				var stream = fs.createReadStream(path.join(rootpath, data.msgdata.messageID + ".png"));
				data.log(json);
				var obj = {
						body: `Pictures of Lizard`,
						attachment: ([stream])
					};
				return data.facebookapi.sendMessage(obj, data.msgdata.threadID, data.msgdata.messageID);
			})
		}
module.exports = {
	lizards: lizards,
	onLoad
}
