var fetch = global.nodemodule["node-fetch"];

function onLoad(data) {

var onLoadText = "\n\n";
onLoadText += "Đang tải \"AdminBotChat\" by DauPhu\n";
onLoadText += "\n";
onLoadText += "=============================\n";
onLoadText += "+                           +\n";
onLoadText += "+                           +\n";
onLoadText += "+  A D M I N B O T C H A T  +\n";
onLoadText += "+                           +\n";
onLoadText += "+                           +\n";
onLoadText += "=============================\n";
onLoadText += "#############################\n";
onLoadText += "                             \n"
onLoadText += "      Copyright By Tofu      \n";
onLoadText += "                             \n";
onLoadText += "#############################\n";
onLoadText += "\n";
onLoadText += "Đã tải xong plugins và sẵn sàng hoạt động ~~!";

data.log(onLoadText);
data.log(data);

}

var adminbotchat = function adminbotchat(type, data) {
	(async function () {
		var returntext = `꧁Bạn đang sử dụng Bot Sliver꧂\n=--+ミ★๖Tɦôηɠ тĭη αɗмĭη bσт ηàү★彡+--=\n𝗔𝗗𝗠𝗜𝗡 𝗡𝗔𝗠𝗘 : Thìn\nNăm sinh : 2000\nQuotes : Cái chết có vẻ đau đớn . Nơi bạn nhìn vào nó là một màu đen tối. Bạn chỉ có một mình. Nhưng không khác khi bạn còn sống, đúng không? Dù chúng ta có bao nhiêu mối quan hệ, chúng ta đều đơn độc.\n𝗧𝗶́𝗻𝗵 𝗰𝗮́𝗰𝗵 : Ít nói, Thích ở một mình, Tính cách hướng nội, Không có tài năng hay thiên phú\n𝗖𝗵𝗶𝗲̂̀𝘂 𝗰𝗮𝗼 : 1m72\n𝑺𝒐̛̉ 𝑻𝒉𝒊́𝒄𝒉 : Nghe nhạc, xem Anime và Phim có Kim So Hyun đóng\nChơi LMHT - Bomb Heros - NinjaSchool Online - Một số tựa game MMORPG\nĐọc tiểu thuyết trên mạng \n𝐈𝐃 𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤 : 100025891215419 \n𝐋𝐢𝐧𝐤 F𝐚𝐜𝐞𝐛𝐨𝐨𝐤 A𝐝𝐦𝐢𝐧 : https://www.facebook.com/huuthin.nguyen.9678/\n𝑽𝒂̀𝒊 𝒍𝒐̛̀𝒊 𝒕𝒐̛́𝒊 𝒃𝒂̣𝒏 𝒅𝒖̀𝒏𝒈 : Vui lòng không spam khi sử dụng và trân thành cảm ơn bạn đã sử dụng sản phẩm\n𝙇𝙪̛𝙪 𝙮́ : Đừng có dại dột mà add 2 bot kẻo bị phát hiện là bạn toang đó <3\n𝑪𝒂̉𝒏𝒉 𝒃𝒂́𝒐 : Vui lòng không dùng bot với mục đích xấu hay cố ý report acc facebook. \nBot chỉ thuộc quyền sở hữu của mình Admin. Mọi hành vi giả danh Admin bán hay cho thuê bot này. Các bạn chửi thẳng mặt thằng giả mạo cho mình. Vì Bot là FREE và Admin chỉ có một\nChúc bạn sử dụng vui vẻ <3\n=--+Gió Phương Bắc+--=`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	adminbotchat: adminbotchat,
	onLoad
};