var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
var tweet = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" ")); 
 var sender = data.msgdata.senderID;
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "tweet <text> [Viết tweet]"
		}
	} else {
		try {
			var img = "https://graph.facebook.com/" + sender + "/picture?height=720&width=720&access_token=EAAAAZAw4FxQIBAHrIZAjgIy8bzwwqQBEglLVfXP6SwZAnKusTnYKMpzFRh7fA69E7K0LDu60XeEPsAZCkwSCTk5r2bVECgwime0oB8p7y8NnP9lS9ZCFcbSFf9ovNeZBdMHqGCmjMWY4HF03IZCe3n6E0I7ZCdDAS6GMizZBWuP91gwsO6SbZCzzmq"
			var name = encodeURIComponent(global.data.cacheName["FB-" + sender]);
			data.log(name)
			data.log(sender)
			data.log(text)
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=tweet&image=${img}&text=${text}&username=${name}&raw=1`);
			var buffer = await fetchdata.buffer();
				var tweet = new streamBuffers.ReadableStreamBuffer({
					frequency: 10,
					chunkSize: 1024
				});
				tweet.path = 'image.png';
				tweet.put(buffer);
				tweet.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([tweet])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
module.exports = {
	tweet: tweet,
}