# osu-plugin-for-c3cbot-0.x
 - Đổi apikey từ https://osu.ppy.sh/p/api trong owo.js trước khi dùng
 - Sử dụng cho https://github.com/c3cbot/c3c-0x
