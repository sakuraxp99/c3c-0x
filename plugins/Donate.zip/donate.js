var fetch = global.nodemodule["node-fetch"];

var donate_get = function donate_get(type, data) {
	(async function () {
		var returntext = `Link donate MoMo: https://nhantien.momo.vn/DF8JzwPI8kz \nCái này là tự nguyện không ép buộc`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	donate_get: donate_get
}