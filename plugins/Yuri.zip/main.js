var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
var yuri = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" ")); 
 if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "yuri <text> [edit chữ vào ảnh]"
		}
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=ddlc&character=y&background=class&body=2b&face=b&text=${text}&raw=1`); data.log(text)
			var buffer = await fetchdata.buffer();
				var yuri = new streamBuffers.ReadableStreamBuffer({
					frequency: 10,
					chunkSize: 1024
				});
				yuri.path = 'image.png';
				yuri.put(buffer);
				yuri.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([yuri])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
module.exports = {
	yuri: yuri,
}